<script type="text/javascript">
	var csetColorSchemes = [<?php echo '\''.implode('\',\'',$schemes).'\''; ?>];
</script>
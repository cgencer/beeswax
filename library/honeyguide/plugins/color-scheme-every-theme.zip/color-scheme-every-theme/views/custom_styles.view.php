<style type="text/css">
	<?php echo $styles; ?>
</style>